from sklearn.model_selection import train_test_split
from odps import ODPS
from torch.nn.utils.rnn import pad_sequence
from config import config
import torch
import pandas as pd


def get_data():
    o = ODPS(
            'LTAI5tDADMFPw1WQaXoFmN7v',
            'ku51eCL192gTLugwyq1u4kAHlm8K9X',
            project='recom_learning',
            endpoint='https://service.cn-beijing.maxcompute.aliyun.com/api',
        )

    # 读取数据。
    sql = '''
    SELECT *
    FROM recom_learning.user_pay_sample_feature_join_dnn_seq_shuffle
    limit 10000
    ;
    '''
    print(sql)

    query_job = o.execute_sql(sql)
    result = query_job.open_reader(tunnel=True)
    df = result.to_pandas(n_process=10)   
    print('read data finish')

    # 删除非特征列
    df = df.drop(columns=['key_all'])

    # 分离特征和标签
    X = df.drop(columns='label')
    y = df['label']

    # 划分训练集和测试集
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    feature_cols = config["feature_col"]
    train_feature_numpy = {}
    test_feature_numpy = {}

    for feature in feature_cols:
        train_feature_numpy[feature] = X_train[feature].values
        test_feature_numpy[feature] = X_test[feature].values

    train_label = y_train.values
    test_label = y_test.values
    
    return train_feature_numpy,test_feature_numpy,train_label,test_label



def my_collate_fn(batch):
    res_features_tmp = {}
    labels = []
    for ff in config["feature_col"]:
        res_features_tmp[ff] = []
    for sample in batch:
        for ff in config["feature_col"]:
            res_features_tmp[ff].append(sample[ff])
        labels.append(sample['labels'])
        
    res_feature = {}
    for ff in config["feature_col"]:
        res_feature[ff] = pad_sequence(res_features_tmp[ff], batch_first=True, padding_value=0)
    return res_feature, torch.tensor(labels)


def get_data_test(brand_id):
    o = ODPS(
            'LTAI5tDADMFPw1WQaXoFmN7v',
            'ku51eCL192gTLugwyq1u4kAHlm8K9X',
            project='recom_learning',
            endpoint='https://service.cn-beijing.maxcompute.aliyun.com/api',
        )

    # 读取数据。
    sql = '''
    SELECT *
    FROM recom_learning.user_pay_sample_feature_join_eval_dnn_seq
    where key_all='{brand_id}'
    ;
    '''.format(brand_id=brand_id)
    print(sql)

    query_job = o.execute_sql(sql)
    result = query_job.open_reader(tunnel=True)
    df = result.to_pandas(n_process=10)   
    print('read data finish')

    # 删除非特征列
    df = df.drop(columns=['key_all'])

    # 分离特征和标签
    X = df.drop(columns='label')
    y = df['label']

    # 划分训练集和测试集
    feature_cols = config["feature_col"]
    test_feature_numpy = {}

    for feature in feature_cols:
        test_feature_numpy[feature] = X[feature].values
    
    test_label = y.values
    
    return test_feature_numpy, test_label


def calculate_top_k_ratio(predictions, labels, top_k_list):
    # 将预测和标签转换为DataFrame
    results_df = pd.DataFrame({'prediction': predictions, 'label': labels})
    
    # 按预测分数降序排序
    results_df = results_df.sort_values(by='prediction', ascending=False)
    
    # 计算总正例数
    total_positives = (results_df['label'] == 1).sum()
    
    # 计算不同top数量下的正例比例
    ratios = {}
    for k in top_k_list:
        top_k_df = results_df.head(k)
        top_k_positives = (top_k_df['label'] == 1).sum()
        ratio = top_k_positives / total_positives
        ratios[k] = ratio
    
    return ratios